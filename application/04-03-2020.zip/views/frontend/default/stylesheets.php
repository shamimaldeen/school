<link rel="shortcut icon" href="assets/images/favicon.png">
<link rel="apple-touch-icon" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/img/icons/apple-touch-icon.png">
<!-- Place favicon.ico in the root directory -->
<link rel="stylesheet" type="text/css" media="print" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/css/print.css" />
<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/css/magnific-popup.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/css/owl.theme.default.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/css/main.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/css/responsive.css">

<link href="https://fonts.googleapis.com/css?family=Crimson+Text:400,400i,600,600i,700,700i|Lato:400,700" rel="stylesheet">
<script src="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/js/vendor/jquery-2.1.4.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkSQBRz8ELzVHMLW8hBYEWByd_icFPQho"></script>
<script src="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/js/gmap3.min.js"></script>
<script src="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/js/vendor/modernizr-2.8.3.min.js"></script>
<script src='https://www.google.com/recaptcha/api.js'></script>
