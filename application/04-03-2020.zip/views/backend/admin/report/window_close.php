<script>
    alert('Please add the Exam Schedule');
    window.close();
</script>