<div class="page-error-404">
	<div class="error-symbol">
		<i class="entypo-attention"></i>
	</div>

	<div class="error-text">
		<h2>404</h2>
		<p><?php echo get_phrase('sorry_you_are_not_authorized_to_access_this_page'); ?></p>
	</div>
	<hr />
</div>
